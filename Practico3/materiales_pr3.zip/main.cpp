#include "CImg.h"

using namespace cimg_library;

void blur_gpu(float * image, int width, int height, int m_size);
void blur_cpu(float * image_in, int width, int height, float * image_out, int m_size);
void ajustar_brillo_cpu(float * img_in, int width, int height, float * img_out, float coef);
void ajustar_brillo_gpu(float * img_in, int width, int height, float * img_out, float coef, int coalesced=1);
    
int main(int argc, char** argv){


	const char * path;

	if (argc < 2) printf("Debe ingresar el nombre del archivo\n");
	else
		path = argv[argc-1];

	CImg<float> image(path);
	CImg<float> image_out(image.width(), image.height(),1,1,0);

	float *img_matrix = image.data();
    float *img_out_matrix = image_out.data();

	float elapsed = 0;

	ajustar_brillo_cpu(img_matrix, image.width(), image.height(), img_out_matrix, 100);

   	image_out.save("output_brillo.ppm");
   	
    return 0;
}

